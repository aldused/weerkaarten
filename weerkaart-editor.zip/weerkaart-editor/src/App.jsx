import { useState, useRef, useCallback, useEffect } from "react";
const CW = 1920, CH = 1080, FONT = "'Amsi Pro','Fredoka','DM Sans',sans-serif";
const isElectron = typeof window !== 'undefined' && window.electronAPI;
const DEFAULT_BG = "./RijnmondKaart.jpg";

// ─── MAP EXTENT (matches RegioNieuw.jpg) ───────
const MAP = { w: 3.55, e: 5.35, s: 51.58, n: 52.08 };
const geo2px = (lon, lat) => ({
  x: ((lon - MAP.w) / (MAP.e - MAP.w)) * CW,
  y: ((MAP.n - lat) / (MAP.n - MAP.s)) * CH,
});

// ─── CITIES WITH COORDINATES ───────────────────
const PRESET_CITIES = [
  { name: "Rotterdam", lon: 4.4777, lat: 51.9244 },
  { name: "Dordrecht", lon: 4.6901, lat: 51.8133 },
  { name: "Gorinchem", lon: 5.0228, lat: 51.8351 },
  { name: "Hoek van Holland", lon: 4.1267, lat: 51.9775 },
  { name: "Hellevoetsluis", lon: 4.1333, lat: 51.8333 },
  { name: "Oude-Tonge", lon: 4.2167, lat: 51.7583 },
  { name: "Ouddorp", lon: 3.91, lat: 51.8150 },
  { name: "Rockanje", lon: 4.02, lat: 51.8700 },
  { name: "Stellendam", lon: 4.0333, lat: 51.7917 },
  { name: "Numansdorp", lon: 4.4333, lat: 51.7250 },
  { name: "Vlaardingen", lon: 4.3422, lat: 51.9128 },
  { name: "Schiedam", lon: 4.3889, lat: 51.9175 },
  { name: "Barendrecht", lon: 4.5347, lat: 51.8567 },
  { name: "Strijen", lon: 4.5500, lat: 51.7417 },
  { name: "Berkel en Rodenrijs", lon: 4.4833, lat: 51.9917 },
  { name: "Bleskensgraaf", lon: 4.7750, lat: 51.8667 },
  { name: "Ridderkerk", lon: 4.6019, lat: 51.8711 },
];
const DAGEN = ["Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag","Zondag"];

// ─── ICON DEFS & COMPONENTS ────────────────────
const IconDefs = () => (
  <defs>
    <linearGradient id="cw" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#FAFBFC"/><stop offset="100%" stopColor="#D8DCE0"/></linearGradient>
    <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#C4C8CC"/><stop offset="100%" stopColor="#8E9298"/></linearGradient>
    <linearGradient id="cd" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#7A7E84"/><stop offset="100%" stopColor="#4A4E54"/></linearGradient>
    <radialGradient id="sg" cx="45%" cy="40%" r="55%"><stop offset="0%" stopColor="#FFF176"/><stop offset="45%" stopColor="#FFC107"/><stop offset="100%" stopColor="#E65100"/></radialGradient>
    <filter id="cs"><feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="rgba(0,0,0,0.18)"/></filter>
    <filter id="glow"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <filter id="ss"><feDropShadow dx="0" dy="1" stdDeviation="2" floodColor="rgba(0,0,0,0.12)"/></filter>
  </defs>
);
const Cl = ({cx,cy,rx,ry,s,d=0}) => <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={d===0?"url(#cw)":d===1?"url(#cg)":"url(#cd)"} filter="url(#cs)"/>;
const Drop = ({x,y,s,l=.17,w=.038}) => <line x1={s*x} y1={s*y} x2={s*(x-.035)} y2={s*(y+l)} stroke="#5CA8E8" strokeWidth={s*w} strokeLinecap="round" filter="url(#ss)"/>;
const Flk = ({x,y,s,z=.038}) => (<g transform={`translate(${s*x},${s*y})`} filter="url(#ss)"><line x1={-s*z} y1={0} x2={s*z} y2={0} stroke="#fff" strokeWidth={s*.016}/><line x1={0} y1={-s*z} x2={0} y2={s*z} stroke="#fff" strokeWidth={s*.016}/><line x1={-s*z*.7} y1={-s*z*.7} x2={s*z*.7} y2={s*z*.7} stroke="#fff" strokeWidth={s*.010}/><line x1={s*z*.7} y1={-s*z*.7} x2={-s*z*.7} y2={s*z*.7} stroke="#fff" strokeWidth={s*.010}/></g>);

const Icon = ({ type, s = 250 }) => {
  const Sun = (cx,cy,rf,gl=true) => (<g>{gl&&<circle cx={cx} cy={cy} r={s*rf*1.8} fill="rgba(255,193,7,0.10)"/>}{Array.from({length:12}).map((_,i)=>{const a=i*30*Math.PI/180;return <line key={i} x1={cx+Math.cos(a)*s*rf*1.15} y1={cy+Math.sin(a)*s*rf*1.15} x2={cx+Math.cos(a)*s*rf*1.45} y2={cy+Math.sin(a)*s*rf*1.45} stroke="#F9A825" strokeWidth={s*.025} strokeLinecap="round"/>;})}<circle cx={cx} cy={cy} r={s*rf} fill="url(#sg)" filter="url(#ss)"/></g>);
  switch (type) {
    case "zon": return Sun(s*.5,s*.5,.19);
    case "sluierbewolking": return (<g>{Sun(s*.5,s*.48,.17)}<ellipse cx={s*.32} cy={s*.36} rx={s*.26} ry={s*.06} fill="rgba(255,255,255,0.28)"/><ellipse cx={s*.62} cy={s*.56} rx={s*.28} ry={s*.07} fill="rgba(255,255,255,0.22)"/><ellipse cx={s*.44} cy={s*.70} rx={s*.30} ry={s*.055} fill="rgba(255,255,255,0.18)"/></g>);
    case "sluierwolken": return (<g><ellipse cx={s*.28} cy={s*.32} rx={s*.28} ry={s*.07} fill="rgba(200,215,230,0.45)"/><ellipse cx={s*.62} cy={s*.46} rx={s*.32} ry={s*.08} fill="rgba(195,210,225,0.40)"/><ellipse cx={s*.40} cy={s*.60} rx={s*.30} ry={s*.065} fill="rgba(200,215,228,0.35)"/><ellipse cx={s*.66} cy={s*.72} rx={s*.24} ry={s*.055} fill="rgba(205,218,232,0.30)"/></g>);
    case "halfbewolkt": return (<g>{Sun(s*.28,s*.25,.11)}{Cl({cx:s*.60,cy:s*.62,rx:s*.32,ry:s*.17,s})}{Cl({cx:s*.44,cy:s*.54,rx:s*.22,ry:s*.14,s})}{Cl({cx:s*.55,cy:s*.46,rx:s*.17,ry:s*.12,s})}</g>);
    case "zon_wolk": return (<g>{Sun(s*.26,s*.23,.10)}{Cl({cx:s*.60,cy:s*.63,rx:s*.34,ry:s*.19,s})}{Cl({cx:s*.44,cy:s*.55,rx:s*.24,ry:s*.16,s})}{Cl({cx:s*.56,cy:s*.47,rx:s*.20,ry:s*.13,s})}{Cl({cx:s*.70,cy:s*.57,rx:s*.15,ry:s*.11,s})}</g>);
    case "zon_groot_stapelwolk": return (<g>{Sun(s*.28,s*.25,.16)}{Cl({cx:s*.64,cy:s*.66,rx:s*.30,ry:s*.16,s})}{Cl({cx:s*.62,cy:s*.54,rx:s*.24,ry:s*.14,s})}{Cl({cx:s*.58,cy:s*.44,rx:s*.18,ry:s*.12,s})}{Cl({cx:s*.54,cy:s*.58,rx:s*.17,ry:s*.12,s})}{Cl({cx:s*.72,cy:s*.60,rx:s*.14,ry:s*.10,s})}</g>);
    case "zon_stapelwolk": return (<g>{Sun(s*.24,s*.22,.09)}{Cl({cx:s*.60,cy:s*.64,rx:s*.32,ry:s*.17,s})}{Cl({cx:s*.58,cy:s*.52,rx:s*.26,ry:s*.14,s})}{Cl({cx:s*.54,cy:s*.42,rx:s*.20,ry:s*.12,s})}{Cl({cx:s*.50,cy:s*.56,rx:s*.17,ry:s*.12,s})}{Cl({cx:s*.68,cy:s*.58,rx:s*.15,ry:s*.11,s})}</g>);
    case "zon_donkere_wolk": return (<g>{Sun(s*.24,s*.23,.10)}{Cl({cx:s*.60,cy:s*.60,rx:s*.34,ry:s*.19,s,d:2})}{Cl({cx:s*.44,cy:s*.52,rx:s*.24,ry:s*.15,s,d:1})}{Cl({cx:s*.68,cy:s*.52,rx:s*.16,ry:s*.11,s,d:2})}</g>);
    case "halfbewolkt_regen": return (<g>{Sun(s*.26,s*.20,.09)}{Cl({cx:s*.60,cy:s*.46,rx:s*.32,ry:s*.17,s,d:1})}{Cl({cx:s*.44,cy:s*.40,rx:s*.22,ry:s*.13,s})}{Cl({cx:s*.54,cy:s*.34,rx:s*.15,ry:s*.10,s})}<Drop x={.46} y={.64} s={s}/><Drop x={.58} y={.68} s={s}/><Drop x={.70} y={.64} s={s}/></g>);
    case "zon_wolk_regen": return (<g>{Sun(s*.22,s*.18,.08,false)}{Cl({cx:s*.58,cy:s*.42,rx:s*.34,ry:s*.19,s,d:1})}{Cl({cx:s*.42,cy:s*.36,rx:s*.24,ry:s*.15,s,d:1})}<Drop x={.40} y={.62} s={s}/><Drop x={.52} y={.66} s={s}/><Drop x={.64} y={.64} s={s}/><Drop x={.74} y={.60} s={s}/></g>);
    case "bewolkt": return (<g>{Cl({cx:s*.54,cy:s*.58,rx:s*.34,ry:s*.19,s})}{Cl({cx:s*.38,cy:s*.50,rx:s*.24,ry:s*.15,s})}{Cl({cx:s*.66,cy:s*.48,rx:s*.20,ry:s*.13,s})}{Cl({cx:s*.52,cy:s*.42,rx:s*.18,ry:s*.12,s})}</g>);
    case "dubbele_wolk": return (<g>{Cl({cx:s*.44,cy:s*.44,rx:s*.30,ry:s*.16,s,d:1})}{Cl({cx:s*.34,cy:s*.38,rx:s*.18,ry:s*.12,s,d:1})}{Cl({cx:s*.62,cy:s*.62,rx:s*.32,ry:s*.18,s})}{Cl({cx:s*.48,cy:s*.56,rx:s*.22,ry:s*.14,s})}{Cl({cx:s*.72,cy:s*.56,rx:s*.15,ry:s*.12,s})}</g>);
    case "driedubbele_wolk": return (<g>{Cl({cx:s*.38,cy:s*.36,rx:s*.26,ry:s*.13,s,d:1})}{Cl({cx:s*.52,cy:s*.50,rx:s*.30,ry:s*.16,s,d:1})}{Cl({cx:s*.36,cy:s*.46,rx:s*.17,ry:s*.11,s,d:1})}{Cl({cx:s*.66,cy:s*.66,rx:s*.32,ry:s*.18,s})}{Cl({cx:s*.52,cy:s*.60,rx:s*.22,ry:s*.14,s})}{Cl({cx:s*.76,cy:s*.60,rx:s*.15,ry:s*.12,s})}</g>);
    case "2druppels": return (<g><Drop x={.38} y={.36} s={s} l={.22} w={.042}/><Drop x={.62} y={.36} s={s} l={.22} w={.042}/></g>);
    case "3druppels": return (<g><Drop x={.30} y={.36} s={s} l={.22} w={.042}/><Drop x={.50} y={.33} s={s} l={.22} w={.042}/><Drop x={.70} y={.36} s={s} l={.22} w={.042}/></g>);
    case "4druppels": return (<g><Drop x={.26} y={.30} s={s} l={.22} w={.042}/><Drop x={.46} y={.27} s={s} l={.22} w={.042}/><Drop x={.66} y={.30} s={s} l={.22} w={.042}/><Drop x={.46} y={.55} s={s} l={.22} w={.042}/></g>);
    case "regen": return (<g>{Cl({cx:s*.54,cy:s*.36,rx:s*.34,ry:s*.19,s,d:1})}{Cl({cx:s*.38,cy:s*.30,rx:s*.24,ry:s*.14,s,d:1})}<Drop x={.38} y={.56} s={s}/><Drop x={.50} y={.60} s={s}/><Drop x={.62} y={.58} s={s}/><Drop x={.72} y={.55} s={s}/></g>);
    case "sneeuw": return (<g>{Cl({cx:s*.54,cy:s*.34,rx:s*.34,ry:s*.19,s,d:1})}{Cl({cx:s*.38,cy:s*.28,rx:s*.22,ry:s*.13,s,d:1})}<Flk x={.36} y={.60} s={s}/><Flk x={.52} y={.66} s={s}/><Flk x={.68} y={.60} s={s}/><Flk x={.44} y={.76} s={s}/><Flk x={.60} y={.76} s={s}/></g>);
    case "zware_sneeuw": return (<g>{Cl({cx:s*.54,cy:s*.30,rx:s*.36,ry:s*.19,s,d:2})}{Cl({cx:s*.38,cy:s*.24,rx:s*.24,ry:s*.13,s,d:2})}{[[.30,.54],[.44,.58],[.58,.56],[.72,.52],[.36,.70],[.52,.74],[.66,.70],[.44,.86],[.58,.86]].map(([px,py],i)=><Flk key={i} x={px} y={py} s={s} z={.040}/>)}</g>);
    case "winterse_bui": return (<g>{Sun(s*.20,s*.17,.07,false)}{Cl({cx:s*.58,cy:s*.40,rx:s*.34,ry:s*.19,s,d:2})}{Cl({cx:s*.42,cy:s*.34,rx:s*.22,ry:s*.14,s,d:1})}<Drop x={.36} y={.60} s={s} l={.14}/><Drop x={.52} y={.62} s={s} l={.14}/><Flk x={.68} y={.62} s={s} z={.030}/><Flk x={.44} y={.78} s={s} z={.030}/><circle cx={s*.58} cy={s*.80} r={s*.022} fill="#E8F4FD" stroke="#78B8E8" strokeWidth={s*.005}/><circle cx={s*.72} cy={s*.76} r={s*.022} fill="#E8F4FD" stroke="#78B8E8" strokeWidth={s*.005}/></g>);
    case "hagelstenen": return (<g>{[[.34,.36],[.54,.32],[.74,.36],[.44,.56],[.64,.54],[.54,.72]].map(([px,py],i)=><g key={i}><circle cx={s*px} cy={s*py} r={s*.036} fill="#E8F4FD" stroke="#78B8E8" strokeWidth={s*.006} filter="url(#ss)"/><circle cx={s*px-s*.012} cy={s*py-s*.012} r={s*.011} fill="rgba(255,255,255,0.45)"/></g>)}</g>);
    case "hagel": return (<g>{Cl({cx:s*.54,cy:s*.32,rx:s*.36,ry:s*.20,s,d:2})}{Cl({cx:s*.38,cy:s*.26,rx:s*.24,ry:s*.14,s,d:1})}<Drop x={.38} y={.54} s={s} l={.12}/><Drop x={.58} y={.56} s={s} l={.12}/>{[[.44,.68],[.56,.72],[.68,.66],[.52,.80]].map(([px,py],i)=><g key={i}><circle cx={s*px} cy={s*py} r={s*.024} fill="#E8F4FD" stroke="#78B8E8" strokeWidth={s*.005}/></g>)}</g>);
    case "ijzel": return (<g>{Cl({cx:s*.54,cy:s*.30,rx:s*.36,ry:s*.20,s,d:1})}{Cl({cx:s*.38,cy:s*.25,rx:s*.24,ry:s*.14,s,d:1})}{[[.36,.52],[.48,.56],[.60,.54],[.70,.50]].map(([px,py],i)=><g key={i}><line x1={s*px} y1={s*py} x2={s*(px-.05)} y2={s*(py+.18)} stroke="#80DEEA" strokeWidth={s*.024} strokeLinecap="round"/><g transform={`translate(${s*(px-.05)},${s*(py+.20)})`}><line x1={-s*.014} y1={0} x2={s*.014} y2={0} stroke="#B2EBF2" strokeWidth={s*.011} strokeLinecap="round"/><line x1={0} y1={-s*.014} x2={0} y2={s*.014} stroke="#B2EBF2" strokeWidth={s*.011} strokeLinecap="round"/></g></g>)}<polygon points={`${s*.50},${s*.80} ${s*.44},${s*.90} ${s*.56},${s*.90}`} fill="none" stroke="#FFB74D" strokeWidth={s*.011} strokeLinejoin="round"/><text x={s*.50} y={s*.89} textAnchor="middle" fontSize={s*.055} fontWeight={700} fill="#FFB74D" fontFamily="sans-serif">!</text></g>);
    case "stapelwolk_bliksem": return (<g>{Cl({cx:s*.54,cy:s*.60,rx:s*.36,ry:s*.20,s,d:2})}{Cl({cx:s*.52,cy:s*.46,rx:s*.30,ry:s*.15,s,d:2})}{Cl({cx:s*.48,cy:s*.34,rx:s*.22,ry:s*.13,s,d:1})}<polygon points={`${s*.48},${s*.68} ${s*.57},${s*.68} ${s*.52},${s*.78} ${s*.60},${s*.78} ${s*.46},${s*.94} ${s*.50},${s*.80} ${s*.44},${s*.80}`} fill="#FFD600" filter="url(#glow)"/></g>);
    case "onweer": return (<g>{Cl({cx:s*.54,cy:s*.32,rx:s*.36,ry:s*.20,s,d:2})}{Cl({cx:s*.38,cy:s*.26,rx:s*.24,ry:s*.14,s,d:2})}<polygon points={`${s*.48},${s*.50} ${s*.58},${s*.50} ${s*.52},${s*.64} ${s*.61},${s*.64} ${s*.46},${s*.84} ${s*.51},${s*.66} ${s*.44},${s*.66}`} fill="#FFD600" filter="url(#glow)"/></g>);
    case "mist2": return (<g>{[.42,.58].map((y,i)=><line key={i} x1={s*.18} y1={s*y} x2={s*.82} y2={s*y} stroke="#B0BAC6" strokeWidth={s*.055} strokeLinecap="round" opacity={.5+i*.18}/>)}</g>);
    case "mist3": return (<g>{[.34,.50,.66].map((y,i)=><line key={i} x1={s*(.20-i*.02)} y1={s*y} x2={s*(.80+i*.02)} y2={s*y} stroke="#B0BAC6" strokeWidth={s*.05} strokeLinecap="round" opacity={.42+i*.14}/>)}</g>);
    case "mist": return (<g>{[.28,.38,.48,.58,.68].map((y,i)=>{const w=.30+i*.04;return <line key={i} x1={s*(.5-w)} y1={s*y} x2={s*(.5+w)} y2={s*y} stroke="#B0BAC6" strokeWidth={s*.048} strokeLinecap="round" opacity={.35+i*.11}/>;})}</g>);
    default: return null;
  }
};

const ICON_ROWS = [
  {label:"☀️ Zon",items:["zon","sluierbewolking","sluierwolken"]},
  {label:"⛅ Zon+wolk",items:["halfbewolkt","zon_wolk","zon_groot_stapelwolk","zon_stapelwolk","zon_donkere_wolk"]},
  {label:"🌧️ Buien",items:["halfbewolkt_regen","zon_wolk_regen"]},
  {label:"☁️ Bewolkt",items:["bewolkt","dubbele_wolk","driedubbele_wolk"]},
  {label:"💧 Regen",items:["2druppels","3druppels","4druppels","regen"]},
  {label:"❄️ Winter",items:["sneeuw","zware_sneeuw","winterse_bui","hagelstenen","hagel","ijzel"]},
  {label:"⚡ Onweer",items:["stapelwolk_bliksem","onweer"]},
  {label:"🌫️ Mist",items:["mist2","mist3","mist"]},
];
const IL={zon:"Zon",sluierbewolking:"Zon+sluier",sluierwolken:"Sluierwolken",halfbewolkt:"Half bew.",zon_wolk:"Zon/wolk",zon_groot_stapelwolk:"Grote zon+stapel",zon_stapelwolk:"Stapelwolk",zon_donkere_wolk:"Donk. wolk",halfbewolkt_regen:"Zon+bui",zon_wolk_regen:"Zon/regen",bewolkt:"Bewolkt",dubbele_wolk:"Dubbel",driedubbele_wolk:"Driedubbel","2druppels":"2","3druppels":"3","4druppels":"4",regen:"Wolk+regen",sneeuw:"Sneeuw",zware_sneeuw:"Zwaar",winterse_bui:"Winterse bui",hagelstenen:"Hagelstenen",hagel:"Wolk+hagel",ijzel:"IJzel",stapelwolk_bliksem:"Stapel+⚡",onweer:"Onweer",mist2:"2 strepen",mist3:"3 strepen",mist:"Dichte mist"};
const WDIRS=["N","NNO","NO","ONO","O","OZO","ZO","ZZO","Z","ZZW","ZW","WZW","W","WNW","NW","NNW"];
const d2deg=d=>{const i=WDIRS.indexOf(d);return i>=0?i*22.5:0;};

let nid=1;
export default function App(){
  const [els,setEls]=useState([]);const [selId,setSelId]=useState(null);const [tool,setTool]=useState("select");const [drag,setDrag]=useState(null);
  const [bgImg,setBgImg]=useState(null);const [panel,setPanel]=useState(null);const [showWm,setShowWm]=useState(true);
  const [lastTemp,setLastTemp]=useState("9");const [lastUV,setLastUV]=useState("4");const [pendingLabel,setPendingLabel]=useState(null);
  const svgRef=useRef(null);const fileRef=useRef(null);const loadRef=useRef(null);const cElRef=useRef(false);

  // Load default background as base64 so it embeds in SVG export
  useEffect(()=>{
    const img=new Image();
    img.onload=()=>{const c=document.createElement("canvas");c.width=img.naturalWidth;c.height=img.naturalHeight;c.getContext("2d").drawImage(img,0,0);setBgImg(c.toDataURL("image/jpeg",0.92));};
    img.src=DEFAULT_BG;
  },[]);

  const handleBgUpload=useCallback(async f=>{if(f){const r=new FileReader();r.onload=e=>setBgImg(e.target.result);r.readAsDataURL(f);}},[]);
  const openBg=useCallback(async()=>{if(isElectron){const d=await window.electronAPI.openBg();if(d)setBgImg(d);}else fileRef.current?.click();},[]);
  const saveLayout=useCallback(async()=>{const j=JSON.stringify({els},null,2);if(isElectron)await window.electronAPI.saveLayout(j);else{const b=new Blob([j],{type:"application/json"});const a=document.createElement("a");a.download=`layout_${new Date().toISOString().slice(0,10)}.json`;a.href=URL.createObjectURL(b);a.click();}},[els]);
  const loadLayoutFn=useCallback(async()=>{if(isElectron){const j=await window.electronAPI.loadLayout();if(j)try{const d=JSON.parse(j);if(d.els){setEls(d.els);nid=Math.max(...d.els.map(e=>e.id),0)+1;setSelId(null);}}catch(e){}}else loadRef.current?.click();},[]);
  const exportPNG=useCallback(()=>{const svg=svgRef.current;if(!svg)return;const str=new XMLSerializer().serializeToString(svg);const blob=new Blob([str],{type:"image/svg+xml;charset=utf-8"});const url=URL.createObjectURL(blob);const img=new Image();img.onload=async()=>{const c=document.createElement("canvas");c.width=CW;c.height=CH;c.getContext("2d").drawImage(img,0,0,CW,CH);URL.revokeObjectURL(url);const du=c.toDataURL("image/png");if(isElectron)await window.electronAPI.savePNG(du);else{const a=document.createElement("a");a.download=`weerkaart_${new Date().toISOString().slice(0,10)}.png`;a.href=du;a.click();}};img.src=url;},[]);
  useEffect(()=>{if(!isElectron)return;window.electronAPI.onMenuOpenBg(()=>openBg());window.electronAPI.onMenuSaveLayout(()=>saveLayout());window.electronAPI.onMenuLoadLayout(()=>loadLayoutFn());window.electronAPI.onMenuExportPng(()=>exportPNG());},[openBg,saveLayout,loadLayoutFn,exportPNG]);

  const gc=useCallback(e=>{const svg=svgRef.current;if(!svg)return{x:0,y:0};const r=svg.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*CW,y:(e.clientY-r.top)/r.height*CH};},[]);
  const addEl=useCallback((type,x,y,extra={})=>{const id=nid++;let el={id,type,x,y};if(type==="label")el={...el,value:extra.value||"ROTTERDAM",fontSize:32,color:"#fff"};else if(type==="day")el={...el,value:extra.value||"Maandag",fontSize:56,color:"#fff"};else if(type==="temp")el={...el,value:lastTemp,color:"#fff"};else if(type==="uv")el={...el,value:lastUV,color:"#FFD54F"};else if(type==="wind")el={...el,dir:"ZW",bft:"5",color:"#90CAF9"};else if(type==="seatemp")el={...el,value:"9",color:"#90CAF9"};else if(type==="text")el={...el,value:"TEKST",fontSize:36,color:"#fff"};else el={...el,size:250};setEls(p=>[...p,el]);setSelId(id);},[lastTemp,lastUV]);
  const upd=useCallback((id,u)=>{setEls(p=>{const n=p.map(el=>el.id===id?{...el,...u}:el);const up=n.find(el=>el.id===id);if(up?.type==="temp"&&u.value!==undefined)setLastTemp(u.value);if(up?.type==="uv"&&u.value!==undefined)setLastUV(u.value);return n;});},[]);

  // ─── Place city at geo-coordinates ───────────
  const addCity=useCallback((city)=>{
    const pos = geo2px(city.lon, city.lat);
    addEl("label", pos.x, pos.y, { value: city.name.toUpperCase() });
  },[addEl]);

  const addDay=useCallback((day)=>{setPendingLabel({type:"day",value:day});setTool("select");},[]);

  const onCanvas=useCallback(e=>{
    cElRef.current=false;
    setTimeout(()=>{
      if(cElRef.current) return;
      const c=gc(e);
      if(pendingLabel){addEl(pendingLabel.type,c.x,c.y,{value:pendingLabel.value});setPendingLabel(null);return;}
      if(tool==="select") setSelId(null);
      else addEl(tool,c.x,c.y);
    },0);
  },[tool,addEl,gc,pendingLabel]);

  const onElDown=useCallback((e,id)=>{e.stopPropagation();cElRef.current=true;setSelId(id);setPendingLabel(null);const c=gc(e);const el=els.find(el=>el.id===id);if(el)setDrag({id,ox:c.x-el.x,oy:c.y-el.y});},[els,gc]);
  const onMove=useCallback(e=>{if(!drag)return;const c=gc(e);setEls(p=>p.map(el=>el.id===drag.id?{...el,x:c.x-drag.ox,y:c.y-drag.oy}:el));},[drag,gc]);
  const onUp=useCallback(()=>setDrag(null),[]);
  const del=useCallback(id=>{setEls(p=>p.filter(el=>el.id!==id));setSelId(s=>s===id?null:s);},[]);
  const dup=useCallback(id=>{const el=els.find(e=>e.id===id);if(!el)return;const ni=nid++;setEls(p=>[...p,{...el,id:ni,x:el.x+60,y:el.y+60}]);setSelId(ni);},[els]);
  const sel=els.find(e=>e.id===selId);
  const mvU=useCallback(id=>{setEls(p=>{const i=p.findIndex(e=>e.id===id);if(i<p.length-1){const n=[...p];[n[i],n[i+1]]=[n[i+1],n[i]];return n;}return p;});},[]);
  const mvD=useCallback(id=>{setEls(p=>{const i=p.findIndex(e=>e.id===id);if(i>0){const n=[...p];[n[i],n[i-1]]=[n[i-1],n[i]];return n;}return p;});},[]);
  useEffect(()=>{const h=e=>{const t=document.activeElement?.tagName;if(t==="INPUT"||t==="TEXTAREA"||t==="SELECT")return;if((e.key==="Delete"||e.key==="Backspace")&&selId){e.preventDefault();del(selId);}if(e.key==="Escape"){setTool("select");setPendingLabel(null);}};window.addEventListener("keydown",h);return()=>window.removeEventListener("keydown",h);},[selId,del]);

  const hasCursor=tool!=="select"||pendingLabel;
  const ib=t=>({padding:"4px 10px",borderRadius:6,border:tool===t?"2px solid #60A5FA":"1px solid rgba(255,255,255,0.12)",background:tool===t?"rgba(96,165,250,0.2)":"rgba(255,255,255,0.04)",cursor:"pointer",fontSize:12,fontWeight:tool===t?600:400,color:"#fff",display:"flex",alignItems:"center",gap:4,whiteSpace:"nowrap",fontFamily:FONT});
  const tb=active=>({padding:"7px 14px",borderRadius:6,border:active?"2px solid #60A5FA":"1px solid rgba(255,255,255,0.15)",background:active?"rgba(96,165,250,0.2)":"rgba(255,255,255,0.06)",cursor:"pointer",fontSize:14,fontWeight:active?600:400,color:"#fff",display:"flex",alignItems:"center",gap:5,whiteSpace:"nowrap",fontFamily:FONT});
  const sS={stroke:"#60A5FA",strokeWidth:2.5,strokeDasharray:"6,3"};

  return (
    <div style={{fontFamily:FONT,background:"#0F172A",minHeight:"100vh",display:"flex",flexDirection:"column"}}>
      <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>{if(e.target.files?.[0])handleBgUpload(e.target.files[0]);}}/>
      <input ref={loadRef} type="file" accept=".json" style={{display:"none"}} onChange={e=>{if(e.target.files?.[0]){const r=new FileReader();r.onload=ev=>{try{const d=JSON.parse(ev.target.result);if(d.els){setEls(d.els);nid=Math.max(...d.els.map(el=>el.id),0)+1;setSelId(null);}}catch(err){}};r.readAsText(e.target.files[0]);}}}/>

      <div style={{background:"#1E293B",borderBottom:"1px solid rgba(255,255,255,0.06)",padding:"6px 12px"}}>
        <div style={{display:"flex",alignItems:"center",gap:4,marginBottom:4}}>
          <button onClick={()=>{setTool("select");setPendingLabel(null);}} style={{...ib("select"),padding:"6px 14px",fontSize:13}}>👆 Selecteer</button>
          {pendingLabel&&<span style={{fontSize:13,color:"#60A5FA",fontWeight:600}}>📅 Klik op de kaart om "{pendingLabel.value}" te plaatsen</span>}
          <div style={{flex:1}}/>
          <button onClick={openBg} style={{...ib("_"),fontSize:12}}>🗺️</button>
          <button onClick={saveLayout} style={{...ib("_"),fontSize:12}}>💾</button>
          <button onClick={loadLayoutFn} style={{...ib("_"),fontSize:12}}>📂</button>
          <button onClick={exportPNG} style={{padding:"6px 18px",borderRadius:6,border:"none",background:"#3B82F6",color:"#fff",cursor:"pointer",fontSize:13,fontWeight:600,fontFamily:FONT}}>⬇ PNG</button>
        </div>
        {ICON_ROWS.map((row,ri)=>(
          <div key={ri} style={{display:"flex",alignItems:"center",gap:4,marginBottom:3}}>
            <span style={{fontSize:11,color:"#94A3B8",minWidth:85,textAlign:"right",marginRight:3,fontWeight:600}}>{row.label}</span>
            {row.items.map(t=>(<button key={t} onClick={()=>{setTool(t);setPanel(null);setPendingLabel(null);}} style={ib(t)}><svg width={22} height={22} viewBox="0 0 250 250"><IconDefs/><Icon type={t} s={250}/></svg>{IL[t]}</button>))}
          </div>
        ))}
      </div>
      <div style={{background:"#1a2436",borderBottom:"1px solid rgba(255,255,255,0.1)",padding:"7px 12px",display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
        <button onClick={()=>{setPanel(panel==="cities"?null:"cities");setTool("select");setPendingLabel(null);}} style={tb(panel==="cities")}>📍 Plaatsen</button>
        <button onClick={()=>{setPanel(panel==="days"?null:"days");setTool("select");setPendingLabel(null);}} style={tb(panel==="days")}>📅 Dagen</button>
        <div style={{width:1,height:22,background:"rgba(255,255,255,0.12)"}}/>
        <button onClick={()=>{setTool("temp");setPanel(null);setPendingLabel(null);}} style={tb(tool==="temp")}>🌡️ Temp ({lastTemp}°)</button>
        <button onClick={()=>{setTool("uv");setPanel(null);setPendingLabel(null);}} style={tb(tool==="uv")}>☀️ UV ({lastUV})</button>
        <button onClick={()=>{setTool("wind");setPanel(null);setPendingLabel(null);}} style={tb(tool==="wind")}>💨 Wind</button>
        <button onClick={()=>{setTool("seatemp");setPanel(null);setPendingLabel(null);}} style={tb(tool==="seatemp")}>🌊 Zeewater</button>
        <button onClick={()=>{setTool("text");setPanel(null);setPendingLabel(null);}} style={tb(tool==="text")}>✏️ Tekst</button>
      </div>

      <div style={{display:"flex",flex:1,overflow:"hidden"}}>
        <div style={{flex:1,padding:8,overflow:"auto",display:"flex",justifyContent:"center",alignItems:"flex-start"}} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();const f=e.dataTransfer?.files?.[0];if(f)handleBgUpload(f);}}>
          <svg ref={svgRef} viewBox={`0 0 ${CW} ${CH}`} style={{width:"100%",maxWidth:1100,aspectRatio:"16/9",borderRadius:8,cursor:hasCursor?"crosshair":"default",boxShadow:"0 4px 24px rgba(0,0,0,0.3)"}} onMouseDown={onCanvas} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp} xmlns="http://www.w3.org/2000/svg">
            <IconDefs/>
            {bgImg?<image href={bgImg} x={0} y={0} width={CW} height={CH} preserveAspectRatio="xMidYMid slice"/>:<rect width={CW} height={CH} fill="#2B5EA7"/>}
            {els.map(el=>{const isSel=el.id===selId;
              if(el.type==="label"||el.type==="day"){const fs=el.fontSize||(el.type==="day"?56:32);const tw=el.value.length*fs*.62+24;const th=fs+16;return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-tw/2} y={el.y-th/2} width={tw} height={th} fill="transparent"/>{isSel&&<rect x={el.x-tw/2} y={el.y-th/2} width={tw} height={th} rx={6} fill="none" {...sS}/>}<text x={el.x} y={el.y+fs*.35} fontSize={fs} fontWeight={700} fill={el.color||"#fff"} textAnchor="middle" fontFamily={FONT} letterSpacing={el.type==="day"?1.5:2} stroke="rgba(0,0,0,0.55)" strokeWidth={el.type==="day"?4:5} paintOrder="stroke" style={{pointerEvents:"none"}}>{el.value}</text></g>);}
              if(el.type==="temp"){const tw=Math.max(100,String(el.value).length*38+70);return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-tw/2} y={el.y-42} width={tw} height={84} fill="transparent"/>{isSel&&<rect x={el.x-tw/2} y={el.y-42} width={tw} height={84} rx={8} fill="none" {...sS}/>}<text x={el.x} y={el.y+24} fontSize={62} fontWeight={700} fill={el.color||"#fff"} textAnchor="middle" fontFamily={FONT} stroke="rgba(0,0,0,0.5)" strokeWidth={5} paintOrder="stroke" style={{pointerEvents:"none"}}>{el.value}°</text></g>);}
              if(el.type==="uv"){const r=32;return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-r-10} y={el.y-r-10} width={r*2+20} height={r*2+20} fill="transparent"/>{isSel&&<circle cx={el.x} cy={el.y} r={r+8} fill="none" {...sS}/>}<circle cx={el.x} cy={el.y} r={r} fill={el.color||"#FFD54F"} opacity={.9}/><text x={el.x} y={el.y+10} fontSize={30} fontWeight={700} fill="#fff" textAnchor="middle" fontFamily={FONT} stroke="rgba(0,0,0,0.3)" strokeWidth={2} paintOrder="stroke" style={{pointerEvents:"none"}}>{el.value}</text></g>);}
              if(el.type==="wind"){const cr=44;const fd=d2deg(el.dir);const td=(fd+180)%360;const tr=(td-90)*Math.PI/180;const asx=el.x+Math.cos(tr)*(cr+6),asy=el.y+Math.sin(tr)*(cr+6);const aex=asx+Math.cos(tr)*52,aey=asy+Math.sin(tr)*52;return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-cr-65} y={el.y-cr-65} width={cr*2+130} height={cr*2+130} fill="transparent"/>{isSel&&<circle cx={el.x} cy={el.y} r={cr+10} fill="none" {...sS}/>}<circle cx={el.x} cy={el.y} r={cr} fill={el.color||"#90CAF9"} opacity={.85}/><text x={el.x} y={el.y+11} fontSize={32} fontWeight={700} fill="#fff" textAnchor="middle" fontFamily={FONT} style={{pointerEvents:"none"}}>{el.bft}</text><line x1={asx} y1={asy} x2={aex-Math.cos(tr)*7} y2={aey-Math.sin(tr)*7} stroke="#fff" strokeWidth={5.5} strokeLinecap="round"/><polygon points={`${aex},${aey} ${aex-Math.cos(tr)*24+Math.sin(tr)*15},${aey-Math.sin(tr)*24-Math.cos(tr)*15} ${aex-Math.cos(tr)*24-Math.sin(tr)*15},${aey-Math.sin(tr)*24+Math.cos(tr)*15}`} fill="#fff"/></g>);}
              if(el.type==="seatemp"){return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-65} y={el.y-32} width={130} height={90} fill="transparent"/>{isSel&&<rect x={el.x-65} y={el.y-32} width={130} height={90} rx={8} fill="none" {...sS}/>}<text x={el.x} y={el.y+14} fontSize={40} fontWeight={700} fill={el.color||"#90CAF9"} textAnchor="middle" fontFamily={FONT} stroke="rgba(0,0,0,0.35)" strokeWidth={3} paintOrder="stroke" style={{pointerEvents:"none"}}>{el.value}°</text><path d={`M${el.x-26},${el.y+28} q8,-10 16,0 q8,10 16,0`} fill="none" stroke={el.color||"#90CAF9"} strokeWidth={3.5} strokeLinecap="round"/><path d={`M${el.x-26},${el.y+40} q8,-10 16,0 q8,10 16,0`} fill="none" stroke={el.color||"#90CAF9"} strokeWidth={3.5} strokeLinecap="round"/></g>);}
              if(el.type==="text"){const tw=el.value.length*el.fontSize*.62+16;const th=el.fontSize+14;return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}}><rect x={el.x-6} y={el.y-el.fontSize-2} width={tw} height={th} fill="transparent"/>{isSel&&<rect x={el.x-6} y={el.y-el.fontSize-2} width={tw} height={th} rx={4} fill="none" {...sS}/>}<text x={el.x} y={el.y} fontSize={el.fontSize} fontWeight={600} fill={el.color||"#fff"} fontFamily={FONT} stroke="rgba(0,0,0,0.4)" strokeWidth={3} paintOrder="stroke" style={{pointerEvents:"none"}}>{el.value}</text></g>);}
              const sz=el.size||250;return(<g key={el.id} onMouseDown={e=>onElDown(e,el.id)} style={{cursor:"grab"}} transform={`translate(${el.x-sz/2},${el.y-sz/2})`}><rect x={0} y={0} width={sz} height={sz} fill="transparent"/>{isSel&&<rect x={-5} y={-5} width={sz+10} height={sz+10} rx={8} fill="none" {...sS}/>}<Icon type={el.type} s={sz}/></g>);
            })}
            {showWm&&<text x={CW-20} y={CH-14} textAnchor="end" fontSize={16} fill="rgba(255,255,255,0.5)" fontFamily={FONT} fontWeight={600} style={{pointerEvents:"none"}}>© Ed Aldus</text>}
          </svg>
        </div>
        <div style={{width:260,background:"#1E293B",borderLeft:"1px solid rgba(255,255,255,0.08)",padding:"12px 14px",overflowY:"auto",fontSize:14,flexShrink:0,color:"#CBD5E1",fontFamily:FONT}}>
          {panel==="cities"&&(<div style={{marginBottom:12}}><SL>Klik = direct op de kaart</SL><div style={{display:"flex",flexWrap:"wrap",gap:5}}>{PRESET_CITIES.map(c=>(<button key={c.name} onClick={()=>addCity(c)} style={{padding:"6px 12px",borderRadius:6,border:"1px solid #475569",background:"#334155",color:"#E2E8F0",cursor:"pointer",fontSize:13,whiteSpace:"nowrap",fontFamily:FONT}}>{c.name}</button>))}</div><div style={{height:1,background:"rgba(255,255,255,0.08)",margin:"10px 0"}}/></div>)}
          {panel==="days"&&(<div style={{marginBottom:12}}><SL>Klik dag, dan klik op de kaart</SL><div style={{display:"flex",flexWrap:"wrap",gap:5}}>{DAGEN.map(d=>(<button key={d} onClick={()=>addDay(d)} style={{padding:"7px 14px",borderRadius:6,border:pendingLabel?.value===d?"2px solid #60A5FA":"1px solid #475569",background:pendingLabel?.value===d?"rgba(96,165,250,0.2)":"#334155",color:"#E2E8F0",cursor:"pointer",fontSize:14,fontWeight:700,fontFamily:FONT}}>{d}</button>))}</div><div style={{height:1,background:"rgba(255,255,255,0.08)",margin:"10px 0"}}/></div>)}
          {sel?(<div><SL>Element bewerken</SL>
            {(sel.type==="label"||sel.type==="day")&&(<><Lbl>{sel.type==="day"?"Dag":"Plaatsnaam"}</Lbl><Inp value={sel.value} onChange={e=>upd(sel.id,{value:e.target.value})}/><Lbl>Grootte: {sel.fontSize}px</Lbl><input type="range" min={16} max={90} value={sel.fontSize} onChange={e=>upd(sel.id,{fontSize:+e.target.value})} style={{width:"100%",marginBottom:8}}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {sel.type==="temp"&&(<><Lbl>Temperatuur</Lbl><Inp value={sel.value} onChange={e=>upd(sel.id,{value:e.target.value})}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {sel.type==="uv"&&(<><Lbl>UV-index (1-8)</Lbl><Inp type="number" min={1} max={8} value={sel.value} onChange={e=>upd(sel.id,{value:e.target.value})}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {sel.type==="seatemp"&&(<><Lbl>Zeetemp</Lbl><Inp value={sel.value} onChange={e=>upd(sel.id,{value:e.target.value})}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {sel.type==="wind"&&(<><Lbl>Wind uit</Lbl><Sel value={sel.dir} onChange={e=>upd(sel.id,{dir:e.target.value})}>{WDIRS.map(d=><option key={d}>{d}</option>)}</Sel><Lbl>Bft</Lbl><Inp type="number" min={1} max={12} value={sel.bft} onChange={e=>upd(sel.id,{bft:e.target.value})}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {sel.type==="text"&&(<><Lbl>Tekst</Lbl><Inp value={sel.value} onChange={e=>upd(sel.id,{value:e.target.value})}/><Lbl>Grootte: {sel.fontSize}px</Lbl><input type="range" min={12} max={80} value={sel.fontSize} onChange={e=>upd(sel.id,{fontSize:+e.target.value})} style={{width:"100%",marginBottom:8}}/><Lbl>Kleur</Lbl><Colors sel={sel} upd={upd}/></>)}
            {!["label","day","temp","uv","wind","seatemp","text"].includes(sel.type)&&(<><Lbl>Grootte: {sel.size||250}px</Lbl><div style={{display:"flex",gap:4,marginBottom:6}}>{[150,200,250,300].map(sz=>(<button key={sz} onClick={()=>upd(sel.id,{size:sz})} style={{flex:1,padding:"4px 0",borderRadius:4,fontSize:11,cursor:"pointer",fontFamily:FONT,border:(sel.size||250)===sz?"2px solid #60A5FA":"1px solid #475569",background:(sel.size||250)===sz?"rgba(96,165,250,0.2)":"#334155",color:"#E2E8F0",fontWeight:600}}>{sz}</button>))}</div><input type="range" min={60} max={450} value={sel.size||250} onChange={e=>upd(sel.id,{size:+e.target.value})} style={{width:"100%",marginBottom:8}}/></>)}
            <div style={{display:"flex",gap:4,marginTop:8}}><button onClick={()=>mvD(sel.id)} style={abtn}>↓</button><button onClick={()=>mvU(sel.id)} style={abtn}>↑</button><button onClick={()=>dup(sel.id)} style={abtn}>📋</button><button onClick={()=>del(sel.id)} style={{...abtn,border:"1px solid #7F1D1D",background:"#450a0a",color:"#FCA5A5"}}>🗑️</button></div>
          </div>):!panel&&(<div style={{color:"#64748B",fontSize:11,textAlign:"center",lineHeight:1.8,margin:"16px 0"}}><p>Kies element, klik op kaart.<br/>Esc = annuleer.</p></div>)}
          <div style={{borderTop:"1px solid rgba(255,255,255,0.08)",marginTop:12,paddingTop:10}}><label style={{display:"flex",alignItems:"center",gap:6,fontSize:13,color:"#94A3B8",cursor:"pointer",marginBottom:10}}><input type="checkbox" checked={showWm} onChange={e=>setShowWm(e.target.checked)}/> © Ed Aldus</label><button onClick={()=>{setEls([]);setSelId(null);}} style={{width:"100%",padding:"8px 0",borderRadius:5,border:"1px solid #7F1D1D",background:"#450a0a",cursor:"pointer",fontSize:13,color:"#FCA5A5",fontFamily:FONT}}>🗑️ Alles wissen</button></div>
        </div>
      </div>
    </div>);
}
function Colors({sel,upd}){return <div style={{display:"flex",gap:4,marginBottom:8,flexWrap:"wrap"}}>{["#fff","#FFD54F","#90CAF9","#EF5350","#66BB6A","#CE93D8","#FF8A65","#0F172A"].map(c=><div key={c} onClick={()=>upd(sel.id,{color:c})} style={{width:22,height:22,borderRadius:4,background:c,cursor:"pointer",border:`2px solid ${sel.color===c?"#60A5FA":"rgba(255,255,255,0.12)"}`}}/>)}</div>;}
const abtn={flex:1,padding:"6px 0",borderRadius:5,border:"1px solid #475569",background:"#334155",cursor:"pointer",fontSize:12,color:"#CBD5E1",textAlign:"center"};
function SL({children}){return <div style={{fontWeight:700,fontSize:12,color:"#94A3B8",marginBottom:8,textTransform:"uppercase",letterSpacing:1.2}}>{children}</div>;}
function Lbl({children}){return <div style={{marginBottom:4,color:"#94A3B8",fontSize:12,fontWeight:600}}>{children}</div>;}
function Inp(props){return <input {...props} style={{width:"100%",padding:"6px 8px",borderRadius:5,border:"1px solid #475569",background:"#334155",color:"#E2E8F0",marginBottom:8,fontSize:14,boxSizing:"border-box",fontFamily:FONT,...(props.style||{})}}/>;}
function Sel({children,...props}){return <select {...props} style={{width:"100%",padding:"6px",borderRadius:5,border:"1px solid #475569",background:"#334155",color:"#E2E8F0",marginBottom:8,fontSize:13,fontFamily:FONT}}>{children}</select>;}
