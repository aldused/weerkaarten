const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  savePNG: (dataUrl) => ipcRenderer.invoke('save-png', dataUrl),
  saveLayout: (json) => ipcRenderer.invoke('save-layout', json),
  loadLayout: () => ipcRenderer.invoke('load-layout'),
  openBg: () => ipcRenderer.invoke('open-bg'),

  // Menu events
  onMenuOpenBg: (cb) => ipcRenderer.on('menu:open-bg', cb),
  onMenuSaveLayout: (cb) => ipcRenderer.on('menu:save-layout', cb),
  onMenuLoadLayout: (cb) => ipcRenderer.on('menu:load-layout', cb),
  onMenuExportPng: (cb) => ipcRenderer.on('menu:export-png', cb),
});
