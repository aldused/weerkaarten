const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

const isDev = !app.isPackaged;
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: 'Weerkaart Editor — Ed Aldus',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }

  // Build menu
  const template = [
    {
      label: 'Bestand',
      submenu: [
        {
          label: 'Achtergrond laden...',
          accelerator: 'CmdOrCtrl+O',
          click: () => mainWindow.webContents.send('menu:open-bg'),
        },
        {
          label: 'Layout opslaan',
          accelerator: 'CmdOrCtrl+S',
          click: () => mainWindow.webContents.send('menu:save-layout'),
        },
        {
          label: 'Layout laden...',
          accelerator: 'CmdOrCtrl+Shift+O',
          click: () => mainWindow.webContents.send('menu:load-layout'),
        },
        { type: 'separator' },
        {
          label: 'Exporteer als PNG',
          accelerator: 'CmdOrCtrl+E',
          click: () => mainWindow.webContents.send('menu:export-png'),
        },
        { type: 'separator' },
        { role: 'quit', label: 'Afsluiten' },
      ],
    },
    {
      label: 'Bewerken',
      submenu: [
        { role: 'undo', label: 'Ongedaan maken' },
        { role: 'redo', label: 'Opnieuw' },
        { type: 'separator' },
        { role: 'cut', label: 'Knippen' },
        { role: 'copy', label: 'Kopiëren' },
        { role: 'paste', label: 'Plakken' },
        { role: 'selectAll', label: 'Alles selecteren' },
      ],
    },
    {
      label: 'Venster',
      submenu: [
        { role: 'minimize', label: 'Minimaliseer' },
        { role: 'togglefullscreen', label: 'Volledig scherm' },
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'Developer Tools' },
      ],
    },
  ];

  // macOS app menu
  if (process.platform === 'darwin') {
    template.unshift({
      label: app.name,
      submenu: [
        { role: 'about', label: 'Over Weerkaart Editor' },
        { type: 'separator' },
        { role: 'hide', label: 'Verberg' },
        { role: 'hideOthers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit', label: 'Sluit af' },
      ],
    });
  }

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ─── IPC: Save PNG to disk ─────────────────────
ipcMain.handle('save-png', async (event, dataUrl) => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Weerkaart opslaan als PNG',
    defaultPath: `weerkaart_${new Date().toISOString().slice(0, 10)}.png`,
    filters: [{ name: 'PNG Afbeelding', extensions: ['png'] }],
  });
  if (!filePath) return null;
  const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
  fs.writeFileSync(filePath, Buffer.from(base64, 'base64'));
  return filePath;
});

// ─── IPC: Save layout JSON ────────────────────
ipcMain.handle('save-layout', async (event, jsonString) => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Layout opslaan',
    defaultPath: `layout_${new Date().toISOString().slice(0, 10)}.json`,
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (!filePath) return null;
  fs.writeFileSync(filePath, jsonString, 'utf-8');
  return filePath;
});

// ─── IPC: Load layout JSON ────────────────────
ipcMain.handle('load-layout', async () => {
  const { filePaths } = await dialog.showOpenDialog(mainWindow, {
    title: 'Layout laden',
    filters: [{ name: 'JSON', extensions: ['json'] }],
    properties: ['openFile'],
  });
  if (!filePaths || filePaths.length === 0) return null;
  return fs.readFileSync(filePaths[0], 'utf-8');
});

// ─── IPC: Open background image ───────────────
ipcMain.handle('open-bg', async () => {
  const { filePaths } = await dialog.showOpenDialog(mainWindow, {
    title: 'Achtergrondkaart kiezen',
    filters: [{ name: 'Afbeeldingen', extensions: ['png', 'jpg', 'jpeg', 'webp'] }],
    properties: ['openFile'],
  });
  if (!filePaths || filePaths.length === 0) return null;
  const data = fs.readFileSync(filePaths[0]);
  const ext = path.extname(filePaths[0]).slice(1);
  const mime = ext === 'jpg' ? 'jpeg' : ext;
  return `data:image/${mime};base64,${data.toString('base64')}`;
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
